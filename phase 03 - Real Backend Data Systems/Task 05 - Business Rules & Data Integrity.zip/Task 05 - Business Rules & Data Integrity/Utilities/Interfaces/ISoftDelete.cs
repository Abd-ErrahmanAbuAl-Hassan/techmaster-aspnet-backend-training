﻿namespace Task_05_Business_Rules_Data_Integrity.Utilities.Interfaces
{
    public interface ISoftDelete
    {
        public DateTime? DeletedAt { get; set; }
    }
}

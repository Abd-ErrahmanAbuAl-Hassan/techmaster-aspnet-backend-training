﻿namespace Task_05_Business_Rules_Data_Integrity.Utilities.Enums
{
    public enum PaymentMethod
    {
        VodafoneCashe,
        Instapay,
        Fawry,
        ApplePay,
        CreditCard,
        Cash,
        BankTransfer
    }
}
